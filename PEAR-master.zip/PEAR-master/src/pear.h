#ifndef _PEAR_
#define _PEAR_

#define PROGRAM_NAME            "PEAR"
#define PROGRAM_VERSION         "0.9.2"
#define VERSION_DATE            "March 26 2014"
#define LICENCE                 "Creative Commons Licence"
#define CONTACT                 "Tomas.Flouri@h-its.org and Jiajie.Zhang@h-its.org"

#endif
